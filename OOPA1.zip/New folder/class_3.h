#include<iostream>
using namespace std;

class Name{
private:
	char* firstName;
	char* lastName;
public:
	Name(char* first = nullptr, char* last = nullptr);
	Name(const Name&);
	void setFirstName(char*);
	void setLastName(char*);
	char * getFirstName();
	char * getLastName();
	void copyName(Name&);
	void camelCase();
	void toLower();
	void toUpper();
	int nameLength();
	void swapNames();
	void display();
	char* fullName();
	bool isValidName();
};

