#include"class_3.h"

Name::Name(char* first = nullptr, char* last = nullptr)
{
	
}
Name::Name(const Name&obj)
{
	firstName =  obj.firstName;
	lastName=obj.lastName;
}
void Name::setFirstName(char*_fname)
{
	int ln=0;
	while(true)
	{
		if(_fName[ln]!='\0')
		{
			break;
		}
		else
		{
			ln++;
		}
	}
	firstName=new char [length+1];
	for(int i=0;i<ln;i++)
	{
		firstName[i] = _fName[i];
	}
	firstName[ln]='\0';
}
void Name::setLastName(char*_lName)
{
	int ln=0;
	while(true)
	{
		if(_lName[ln]!='\0')
		{
			break;
		}
		else
		{
			ln++;
		}
	}
	lastName=new char [length+1];
	for(int i=0;i<ln;i++)
	{
		lastName[i] = _lName[i];
	}
	lastName[ln]='\0';
}
char * Name::getFirstName()
{
	int ln=0;
	while(true)
	{
		if(firstName[ln]!='\0')
		{
			break;
		}
		else
		{
			ln++;
		}
	}
	char * temp=new char [length+1];
	for(int i=0;i<ln;i++)
	{
		temp[i] = firstName[i];
	}
	temp[ln]='\0';
}
char * Name:: getLastName()
{
	int ln=0;
	while(true)
	{
		if(lastName[ln]!='\0')
		{
			break;
		}
		else
		{
			ln++;
		}
	}
	char * temp=new char [length+1];
	for(int i=0;i<ln;i++)
	{
		temp[i] = lastName[i];
	}
	temp[ln]='\0';
}
void copyName(Name&obj)
{
	
}
void Name::camelCase()
{
	if(firstName[0] >= 'a'|| firstName[0] <= 'z')
	{
	    firstName[0]=firstName[0]-32;	
	}
	else if(lastName[0] >= 'a'|| lastName[0] <= 'z')
	{
	    lastName[0]=lastName[0]-32;	
	}
}
void Name:: toLower()
{
	for(int i=0;firstName[i]!='\0';i++)
	{
		if(firstName[i]>='A'&&firstName[i]<='Z')
		{
			firstName[i] = firstName[i] + 32;
		}
	}
}
void Name:: toUpper()
{
	for(int i=0;lastName[i]!='\0';i++)
	{
		if(lastName[i]>='A'&&lastName[i]<='Z')
		{
			lastName[i] = lastName[i] + 32;
		}
	}
}
int Name:: nameLength()
{
	int count=0;
	while(true){
		if(firstName[count]!='\0')\{
			break;
		}
		else{
	    	count++;
    	}
	}
	int countL=0;
	while(true){
		if(lastName[countL]!='\0')
		{
			break;
		}
		else
		{
	    	countL++;
    	}
	}
	int total = count+count2;
}
void Name:: swapNames()
{
	char * temp = firstName;
	firstName = lastName;
	lastName = temp;
}
void Name:: display()
{
	cout<<" Name: "<<firstName<<" "<<lastName<<endl;
}
char* Name:: fullName()
{
	return firstName + lastName;
}
bool Name:: isValidName()
{
	while(true){
		if(
	}
}
