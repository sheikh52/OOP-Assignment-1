#include<iostream>
using namespace std;

int main()
{
	Name N1;
	N1.setFirstName("Ali");
	N1.setLastName("Hamza");
//	N1.getFirstName();
//	N1.getLastName();
	Name N2;
	N2.setFirstName("Laiba");
	N2.setLastName("Khan");
//	N2.getFirstName();
//	N2.getLastName();

    int nameCompare(Name N1, Name N2) 
    {
    	if(N1==N2)
    	{
    		return 0;
		}
		else if(N1>N2)
		{
			return > 0;
		}
		else
		{
			return < 0;
		}
	}
	system("pause");
	return 0;
}
