#include"class_2.h"

MyChar::MyChar(char * n)
{
	int length = 0;
	while (true)
	{
		if (n[length] != '\0')
		{
			break;
		}
		else
		{
			length++;
		}
	}

	name = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		name[i] = n[i];
	}

	name[length] = '\0';
}

	
char * MyChar::getChar()
{
	int ln = 0;
	while (true)
	{
		if (name[ln] != '\0')
		{
			break;
		}
		else
		{
			ln++;
		}
	}

	char * temp = new char[ln + 1];
	for (int i = 0; i < ln; i++)
	{
		temp[i] = name[i];
	}
	temp[ln] = '\0';
	return temp;
}

void MyChar::covertUpperCase()
{	
	for (int i = 0; name[i] != '\0'; i++)
	{
		if (name[i] >= 'a' && name[i] <= 'z')
		{
			name[i] = name[i] - 32;
		}
	}
}

void MyChar::covertLowerCase()
{
	for (int i = 0; name[i] != '\0'; i++)
	{
		if (name[i] >= 'A' && name[i] <= 'Z')
		{
			name[i] = name[i] + 32;
		}
	}
}

MyChar::~MyChar()
{
	delete[]name;
	name = nullptr;
	cout << "Default" << endl;
}