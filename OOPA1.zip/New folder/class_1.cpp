#include"class_1.h"

MyNum::MyNum(int _num = 0)
{
	cout << " Constructor executed" << endl;
}

MyNum:: ~MyNum()
{
	cout << "Destructor executed" << endl;
}

void MyNum:: setNum(int _num)
{
	num = _num;
}

int MyNum:: getNum()
{
	return num;
}

void MyNum::convertIntoPositiveNum()
{
	if (num > 0)
	{ 
		num = - (num);
	}
}

void MyNum::convertIntoNegativeNum()
{
	if (num < 0)
	{
		num = -(num);
	}
}