#include<iostream>
using namespace std;

class MyChar
{
	char * name;

public:
	MyChar(char *);
	~MyChar();
	
	char * getChar();
	void covertUpperCase();
	void covertLowerCase();
};