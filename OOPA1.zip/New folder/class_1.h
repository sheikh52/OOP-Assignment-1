#include<iostream>
using namespace std;

class MyNum
{
	int num;
public:
	MyNum(int);
	~MyNum();
	void setNum(int);
	int getNum();
	void convertIntoPositiveNum();
	void convertIntoNegativeNum();
};