#include"class_1.h"

int main()
{
	MyNum  N1setNum(34);
	system("pause");
}