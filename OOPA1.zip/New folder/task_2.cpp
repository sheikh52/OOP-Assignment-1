#include"class_2.h"

int main()
{
	char name[23] = { "Ayesha" };
	MyChar MC1(name);
	cout << MC1.getChar() << endl;

	int N;
	char * chr = {'\0'};
	
	cout << "How many objects you want to enter: ";
	cin >> N;

	
	for (int i = 0; i < N; i++)
	{
		MyChar Ni('\0');
		cout << " Display: "<< Ni.getChar() << endl;
	}
	
	system("pause");
	return 0;
}
